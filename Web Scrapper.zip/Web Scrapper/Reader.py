import sys
import csv
import codecs


reload(sys)
sys.setdefaultencoding('utf-8')


headers = []

with codecs.open('csvTest1', 'r', 'utf-8-sig') as temp:
    reader = csv.reader(temp, delimiter = ',')

    i = 0
    for row in reader:
        if i == 0:
            for property in row:
                headers.append(property)

        print ', '.join(row)

        i += 1

print("")
print("HEADERS", headers)


with codecs.open('csvHeaders', 'w', 'utf-8-sig') as temp:
    writer = csv.writer(temp, delimiter = ',')
    writer.writerow(headers)



