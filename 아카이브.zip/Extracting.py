from bs4 import BeautifulSoup
import requests
import sys
import csv
import codecs

reload(sys)
sys.setdefaultencoding('utf-8')


#initializing html file
with open('test.html') as html_file:
    soup = BeautifulSoup(html_file, 'lxml')

# print(soup.prettify())



table = soup.table
print(table.prettify(formatter = None))



headers = []
cells = table.find_all("td")
rows = table.find_all("tr")
tables = soup.find_all("table")

print(table.contents[0])
cells = [[] for i in range(len(rows)-1)]



#putting each cell into 2D array
for rowIndex in range(0, len(rows)):
        # print('\n')
        # print(rows[rowIndex].prettify())
        # print(" ")
        # thing = rows[rowIndex].find_all('p', class_='p7')
        # print(thing.span.text)
        # print(rows[rowIndex])

    print("")
    print("00000000000000000000000000000000000000000000")
    print("")

    # no rowspan
    for cell in rows[rowIndex].find_all("td"):
        x = cell.span.extract().text
        if rowIndex == 0:
            headers.append(x)
            print(x)
        else:
            if x == "":
                cells[rowIndex-1].append("Empty")
                print("Empty")

            else:
                cells[rowIndex-1] += [x]
                print(x)

    """"""""""""""""""""""""""""""
    # if rows[rowIndex].text == "":
    #     print("Empty")
    #     cells[rowIndex].append("Empty")
    # else:
    #     print(rows[rowIndex].text)
#     cells[rowIndex].append(rows[rowIndex].text)



#unicode cells
print(headers)
print("")

for row in cells:
    print(row)

# with open('csvTest.csv', 'w') as new_file:
#         writer = csv.writer(new_file, delimiter = ',')
#
#         for row in cells:
#             writer.writerow(row)



with codecs.open('csvTest1', 'w', 'utf-8-sig') as temp:
    writer = csv.writer(temp, delimiter = ',')


    writer.writerow(headers)
    writer.writerow("")

    for row in cells[1:]:
        writer.writerow(row)

    #for row in cells:
    #    for word in row:
    #        temp.write(word)



""""""""""""""""""""""""""""""

"""
    for cell in rows[rowIndex].find_all("td"):

        for word in cell:
            if word == "":
                cells[rowIndex].append("Empty")
            else:
                x = word
                cells[rowIndex].append(x)
            print(word)



    curRow = rows[rowIndex].find_all("td")
    print(curRow)

    for cellIndex in range(len(curRow)):

        if curRow[cellIndex].text == "":
            cells[cellIndex].append("Empty")

        else:
            cells[cellIndex].append(curRow[cellIndex].text)
    print(cells[cellIndex])
"""


